﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class FormTop : Form
    {
        Form1 form;
        public FormTop(Form1 form)
        {
            InitializeComponent();
            this.form = form;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            form.addtocart("T-Shirt 1", 10000);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            form.addtocart("T-Shirt 2", 20000);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            form.addtocart("T-Shirt 3", 30000);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class FormBot : Form
    {
        public FormBot(Form1 form)
        {
            InitializeComponent();
            this.form = form;
        }
        Form1 form;

     
        private void button1_Click_1(object sender, EventArgs e)
        {
            form.addtocart("Pants 1", 15000);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            form.addtocart("Pants 2", 25000);
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            form.addtocart("Pants 3", 35000);
        }
    }
}

using System.Data;
using System.Diagnostics;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        DataTable inventory = new DataTable();
        public void addtocart(string item, int cost)
        {
            bool newitem = true;
            for (int i = 0; i < inventory.Rows.Count; i++)
            {
                if (inventory.Rows[i][0].ToString()==item)
                {
                    int count = Convert.ToInt32(inventory.Rows[i][1].ToString());
                    count++;
                    inventory.Rows[i][1] = count;
                    inventory.Rows[i][3] = count*cost;
                    newitem = false;
                    break;
                }
            }
            if (newitem)
            {
                inventory.Rows.Add(item, 1, cost, cost);
            }

            int sub_total = 0;

            for (int i = 0; i < inventory.Rows.Count; i++)
            {
                sub_total += Convert.ToInt32(inventory.Rows[i][3].ToString());
            }
            textBox1.Text = sub_total.ToString();
            textBox2.Text = (sub_total+(sub_total/10)).ToString();
        }
        public Form1()
        {
            InitializeComponent();
            inventory.Columns.Add("Item Name");
            inventory.Columns.Add("Quantity");
            inventory.Columns.Add("Price");
            inventory.Columns.Add("Total");
            dataGridView1.DataSource = inventory;
            dataGridView1.ReadOnly = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            FormOX form = new FormOX(this);
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            panel1.Controls.Add(form);
            form.Show();
        }

        private void topWearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void bottomWearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void accessoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back && inventory.Rows.Count > 0)
            {
                inventory.Rows[dataGridView1.CurrentCell.RowIndex].Delete();
            }

            int sub_total = 0;

            for (int i = 0; i < inventory.Rows.Count; i++)
            {
                sub_total += Convert.ToInt32(inventory.Rows[i][3].ToString());
            }
            textBox1.Text = sub_total.ToString();
            textBox2.Text = (sub_total + (sub_total / 10)).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (inventory.Rows.Count > 0)
            {
                inventory.Rows[dataGridView1.CurrentCell.RowIndex].Delete();
            }


            int sub_total = 0;
            for (int i = 0; i < inventory.Rows.Count; i++)
            {
                sub_total += Convert.ToInt32(inventory.Rows[i][3].ToString());
            }
            textBox1.Text = sub_total.ToString();
            textBox2.Text = (sub_total + (sub_total / 10)).ToString();
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            FormTop form = new FormTop(this);
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            panel1.Controls.Add(form);
            form.Show();
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            FormTop2 form = new FormTop2(this);
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            panel1.Controls.Add(form);
            form.Show();
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            FormBot form = new FormBot(this);
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            panel1.Controls.Add(form);
            form.Show();
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            FormBot2 form = new FormBot2(this);
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            panel1.Controls.Add(form);
            form.Show();
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            FormAcc form = new FormAcc(this);
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            panel1.Controls.Add(form);
            form.Show();
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            FormAcc2 form = new FormAcc2(this);
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            panel1.Controls.Add(form);
            form.Show();
        }
    }
}
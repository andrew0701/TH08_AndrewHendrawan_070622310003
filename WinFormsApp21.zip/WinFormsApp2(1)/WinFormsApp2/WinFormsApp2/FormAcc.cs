﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class FormAcc : Form
    {
        public FormAcc(Form1 form)
        {
            InitializeComponent();
            this.form = form;
        }
        Form1 form;

        private void button1_Click_1(object sender, EventArgs e)
        {
            form.addtocart("Shoes", 100000);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            form.addtocart("Shoes 2", 120000);
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            form.addtocart("Shoes 3", 100000);
        }
    }
}

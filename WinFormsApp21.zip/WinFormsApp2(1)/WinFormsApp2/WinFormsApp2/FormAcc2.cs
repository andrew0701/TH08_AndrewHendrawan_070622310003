﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class FormAcc2 : Form
    {
        public FormAcc2(Form1 form)
        {
            InitializeComponent();
            this.form = form;
        }
        Form1 form;

        private void button1_Click(object sender, EventArgs e)
        {
            form.addtocart("Golden Necklace", 100000);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            form.addtocart("Silver Necklace", 120000);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            form.addtocart("Necklace", 200000);
        }
    }
}
